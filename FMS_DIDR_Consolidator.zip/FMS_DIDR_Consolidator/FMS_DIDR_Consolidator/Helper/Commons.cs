﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Data.SqlClient;
using System.Security.Cryptography;
using System.IO;
using System.Data.Common;

namespace FMS_DIDR_Consolidator
{
    class Commons
    {
        private static string _dsource;
        private static string _dbase;
        private static string _dbUname;
        private static string _dbPword;
        private static string _ConnectionString;
        private static string _devDbase;

        
        public static string ConnectionString()
        {
            //get the connection string from app.config:
            _dsource = ConfigurationManager.AppSettings["DataSource"].ToString();
            _dbase = ConfigurationManager.AppSettings["Database"].ToString();
            _dbUname = Decrypt(ConfigurationManager.AppSettings["UserName"].ToString());
            _dbPword = Decrypt(ConfigurationManager.AppSettings["Password"].ToString());

            //_ConnectionString = "Data Source=" + _dsource + ";Initial Catalog=" + _dbase + ";User ID=" + _dbUname + ";Password=" + _dbPword;
            //for local use
            _ConnectionString = "Data Source=" + _dsource + ";Initial Catalog=" + _dbase + ";Trusted_Connection=True;Integrated Security=SSPI";
            //_ConnectionString = "Data Source=bdowldb13v;Initial Catalog=dbFMS;Trusted_Connection=True;Integrated Security=SSPI";
            return _ConnectionString;
        }

        public static DataSet executeQuery(string procName, SqlParameter[] sqlParameter)
        {
            try
            {
                DataSet ds = new DataSet();
                using (SqlConnection conn = new SqlConnection(ConnectionString()))
                {
                    SqlCommand cmd = new SqlCommand(procName);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddRange(sqlParameter);
                    SqlDataAdapter sda = new SqlDataAdapter(cmd);
                    sda.SelectCommand.CommandTimeout = 1000;
                    sda.Fill(ds);
                    return ds;
                }
            }
            catch (Exception)
            {
                throw;
            }
        }

        public static DataSet executeQuery(string procName)
        {
            try
            {
                DataSet ds = new DataSet();
                using (SqlConnection conn = new SqlConnection(ConnectionString()))
                {
                    SqlCommand cmd = new SqlCommand(procName);
                    cmd.CommandType = CommandType.Text;
                    SqlDataAdapter sda = new SqlDataAdapter(cmd);
                    sda.SelectCommand.CommandTimeout = 1000;
                    sda.Fill(ds);
                    return ds;
                }
            }
            catch (Exception)
            {
                throw;
            }
        }

        public static void executeNonQuery(string sqlCommand)
        {
            SqlConnection conn = new SqlConnection(ConnectionString());
            conn.Open();
            SqlCommand cmdInsert = new SqlCommand(sqlCommand, conn);
            cmdInsert.CommandType = CommandType.Text;
            cmdInsert.ExecuteNonQuery();
            conn.Close();
        }

        #region do not open

        //really? -.-

        static readonly string PasswordHash = "P@S@W@Y";
        static readonly string SaltKey = "S@K0T3B0y";
        static readonly string VIKey = "@5@NP3dR01@6uN@#";

        public static string Decrypt(string encryptedText)
        {
            byte[] cipherTextBytes = Convert.FromBase64String(encryptedText);
            byte[] keyBytes = new Rfc2898DeriveBytes(PasswordHash, Encoding.ASCII.GetBytes(SaltKey)).GetBytes(256 / 8);
            var symmetricKey = new RijndaelManaged() { Mode = CipherMode.CBC, Padding = PaddingMode.None };

            var decryptor = symmetricKey.CreateDecryptor(keyBytes, Encoding.ASCII.GetBytes(VIKey));
            var memoryStream = new MemoryStream(cipherTextBytes);
            var cryptoStream = new CryptoStream(memoryStream, decryptor, CryptoStreamMode.Read);
            byte[] plainTextBytes = new byte[cipherTextBytes.Length];

            int decryptedByteCount = cryptoStream.Read(plainTextBytes, 0, plainTextBytes.Length);
            memoryStream.Close();
            cryptoStream.Close();
            return Encoding.UTF8.GetString(plainTextBytes, 0, decryptedByteCount).TrimEnd("\0".ToCharArray());
        }

        #endregion
    }
}
