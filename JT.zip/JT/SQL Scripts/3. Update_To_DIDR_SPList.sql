-- Will be used as Current Date Run
ALTER procedure DIDR_Tables_allSP_Update  
 --@startDate datetime,  
 --@endDate datetime  
AS  
begin  
   
  
  declare @sql varchar(max), @count int  
  declare @stmnt as nvarchar(max)
  
  set @count = 1  
  
  while @count <= (select count(*) from didr_splist)  
  begin  
  
     select @sql = substring(sp_name,6,len(sp_name)-6) from didr_splist where position =  + @count  order by position 
		 
	 if (@sql = 'ForeignCurrency')
	 begin 
		set @sql = '[Foreign Currency]'
	 end
     
       --select @stmnt = 'select * from ' + @sql + '  where d_lastUpdated is null'
--      select @stmnt = 'update ' + @sql + '  set d_lastUpdated = ''' + convert(nvarchar(max),getdate()) + ''' where d_lastUpdated is null'
      select @stmnt = 'update ' + @sql + '  set d_lastUpdated = null where d_lastUpdated is not null'
	print @stmnt
   exec (@stmnt)
     
   set @count = @count + 1  
  end  
  
  
end  
  
  
-- exec DIDR_Tables_allSP_Update 
--select * from [Foreign Currency]
--select * from BankCharges
--update BankCharges  set d_lastUpdated = 'Oct 15 2018  4:59PM' where d_lastUpdated is null
--update BankCharges  set d_lastUpdated = NULL where d_lastUpdated is not null