﻿using FMS_DIDR_Consolidator.Interfaces;
using FMS_DIDR_Consolidator.Model;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FMS_DIDR_Consolidator
{
    public partial class frmConfiguration : Form
    {
        private IFMSConfiguration ifmsConfig;
        ValidationContext context;

        private static frmConfiguration frmConfig = null;
        FMSConfiguration fmsconfig;
        //Singleton
        public static frmConfiguration Instance()
        {
            if (frmConfig == null)
            {
                frmConfig = new frmConfiguration();
            }
            return frmConfig;
        }

        public frmConfiguration()
        {
            InitializeComponent();
            ifmsConfig = new IFMSConfiguration(Commons.ConnectionString());
            EnabledDisabledFields(false, "Edit");
        }

        private void frmConfiguration_Load(object sender, EventArgs e)
        {
            fmsconfig = new FMSConfiguration();
        }

        private void ClearError()
        {
            lblLogFolder.Text = "";
            lblTSVBackupFolder.Text = "";
            lblTSV_GPG_Source.Text = "";
            lblTimeToSend.Text = "";
            lblTimeToUpload.Text = "";
            lblFingerPrint.Text = "";
            lblPPKPathDIR.Text = "";
            lblGPGKey.Text = "";
            lblSFTPKey.Text = "";
            lblUserName.Text = "";
            lblDIDRStageDIR.Text = "";
            lblPortNo.Text = "";
            lblServerName.Text = "";
        }

        private void EnabledDisabledFields(bool _val, string _text)
        {
            txtDIDRStageDIR.Enabled =
            txtFingerPrint.Enabled =
            txtGPGKey.Enabled =
            txtLogFolder.Enabled =
            txtPortNo.Enabled =
            txtPPKPatheDIR.Enabled =
            txtServerName.Enabled =
            txtSFTPKey.Enabled =
            txtTimeToSend.Enabled =
            txtTimeToUpload.Enabled =
            txtTSVBackupFolder.Enabled =
            txtTSVGPGSource.Enabled =
            txtUserName.Enabled = _val;
            btnEditUpdate.Text = _text;
        }

        private void btnEditUpdate_Click(object sender, EventArgs e)
        {
            if (btnEditUpdate.Text == "Update")
            {
                fmsconfig = new FMSConfiguration();
                var hasError = BindText(fmsconfig);

                //Save To Database
                if (!hasError)
                {

                }
                else
                {
                    MessageBox.Show("Error encountered during update.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                EnabledDisabledFields(true, "Update");
            }
        }

        private bool BindText(FMSConfiguration fmsconfig)
        {
            fmsconfig.LogFolder = txtLogFolder.Text;
            fmsconfig.TSVBackupFolder = txtTSVBackupFolder.Text;
            fmsconfig.TSV_GPG_Source = txtTSVGPGSource.Text;
            fmsconfig.TimeToSend = txtTimeToSend.Text;
            fmsconfig.TimeToUpload = txtTimeToUpload.Text;
            fmsconfig.FingerPrint = txtFingerPrint.Text;
            fmsconfig.PPKPathDIR = txtPPKPatheDIR.Text;
            fmsconfig.GPGKey = txtGPGKey.Text;
            fmsconfig.SFTPKey = txtSFTPKey.Text;
            fmsconfig.UserName = txtUserName.Text;
            fmsconfig.DIDRStageDIR = txtDIDRStageDIR.Text;
            fmsconfig.PortNo = txtPortNo.Text;
            fmsconfig.ServerName = txtServerName.Text;

            return FieldValidation(fmsconfig);
        }

        private bool FieldValidation(FMSConfiguration fmsconfig)
        {
            var hasError = false;
            ClearError();
            context = new ValidationContext(fmsconfig, null, null);
            try
            {
                IList<ValidationResult> errors = new List<ValidationResult>();

                if (!Validator.TryValidateObject(fmsconfig, context, errors, true))
                {
                    foreach (ValidationResult result in errors)
                    {

                        foreach (Label lb in Controls.OfType<GroupBox>().SelectMany(groupBox => groupBox.Controls.OfType<Label>()).ToList())
                        {
                            string[] _name = result.MemberNames.ToArray();
                            var lblname = "lbl" + _name[0].ToString();

                            if (lb.Name.Contains(lblname))
                            {
                                lb.Text = result.ErrorMessage;
                                hasError = true;
                                break;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                hasError = true;
                throw ex;
            }
            finally
            {
                this.Dispose(true);
            }

            return hasError;
        }
        
        #region TextChanged
        /*
        private void txtServerName_TextChanged(object sender, EventArgs e)
        {
            fmsconfig = new FMSConfiguration();
            BindText(fmsconfig);
        }

        private void txtPortNo_TextChanged(object sender, EventArgs e)
        {
            fmsconfig = new FMSConfiguration();
            BindText(fmsconfig);
        }

        private void txtDIDRStageDIR_TextChanged(object sender, EventArgs e)
        {
            fmsconfig = new FMSConfiguration();
            BindText(fmsconfig);
        }

        private void txtUserName_TextChanged(object sender, EventArgs e)
        {
            fmsconfig = new FMSConfiguration();
            BindText(fmsconfig);
        }

        private void txtSFTPKey_TextChanged(object sender, EventArgs e)
        {
            fmsconfig = new FMSConfiguration();
            BindText(fmsconfig);
        }

        private void txtGPGKey_TextChanged(object sender, EventArgs e)
        {
            fmsconfig = new FMSConfiguration();
            BindText(fmsconfig);
        }

        private void txtPPKPatheDIR_TextChanged(object sender, EventArgs e)
        {
            fmsconfig = new FMSConfiguration();
            BindText(fmsconfig);
        }

        private void txtFingerPrint_TextChanged(object sender, EventArgs e)
        {
            fmsconfig = new FMSConfiguration();
            BindText(fmsconfig);
        }

        private void txtTimeToUpload_TextChanged(object sender, EventArgs e)
        {
            fmsconfig = new FMSConfiguration();
            BindText(fmsconfig);
        }

        private void txtTimeToSend_TextChanged(object sender, EventArgs e)
        {
            fmsconfig = new FMSConfiguration();
            BindText(fmsconfig);
        }

        private void txtTSVGPGSource_TextChanged(object sender, EventArgs e)
        {
            fmsconfig = new FMSConfiguration();
            BindText(fmsconfig);
        }

        private void txtTSVBackupFolder_TextChanged(object sender, EventArgs e)
        {
            fmsconfig = new FMSConfiguration();
            BindText(fmsconfig);
        }

        private void txtLogFolder_TextChanged(object sender, EventArgs e)
        {
            fmsconfig = new FMSConfiguration();
            BindText(fmsconfig);
        }*/
        #endregion
    }
}
