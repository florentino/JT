---*******************
use dbFMS
---*******************

--*****************************
--  CREATION OF TABLE
--*****************************
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DIDR_Monitoring]') AND type in (N'U'))
DROP TABLE [dbo].DIDR_Monitoring
GO
CREATE TABLE DIDR_Monitoring(
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[DateUploaded] [DateTime] NULL,
	[Posted] [int] NULL,
)--ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO


--GO
--GRANT EXECUTE ON [dbo].DIDR_Monitoring TO [HO\Users - BDOL Treasury] WITH GRANT OPTION 
--GO
GO
/****** Object:  Table [dbo].[DIDR_ConfigurationData]    Script Date: 08/20/2018 10:07:19 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DIDR_ConfigurationData]') AND type in (N'U'))
DROP TABLE [dbo].[DIDR_ConfigurationData]
GO
/****** Object:  Table [dbo].[DIDR_ConfigurationData]    Script Date: 08/20/2018 10:07:19 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DIDR_ConfigurationData]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[DIDR_ConfigurationData](
	[idx] [int] IDENTITY(1,1) NOT NULL,
	[config_name] [varchar](200) NULL,
	[config_value] [varchar](max) NULL
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
SET IDENTITY_INSERT [dbo].[DIDR_ConfigurationData] ON
INSERT [dbo].[DIDR_ConfigurationData] ([idx], [config_name], [config_value]) VALUES (1, N'sourcefilename', N'C:\DIDR\Interface')
INSERT [dbo].[DIDR_ConfigurationData] ([idx], [config_name], [config_value]) VALUES (2, N'userFile', N'C:\DIDR\Interface\AAF_Files')
INSERT [dbo].[DIDR_ConfigurationData] ([idx], [config_name], [config_value]) VALUES (3, N'forManualUpload', N'C:\DIDR\Interface\ForManualUpload')
INSERT [dbo].[DIDR_ConfigurationData] ([idx], [config_name], [config_value]) VALUES (4, N'outputfilename', N'C:\DIDR\Interface\procFolder')
INSERT [dbo].[DIDR_ConfigurationData] ([idx], [config_name], [config_value]) VALUES (5, N'logFileFolder', N'C:\DIDR\Interface\Logs')
INSERT [dbo].[DIDR_ConfigurationData] ([idx], [config_name], [config_value]) VALUES (6, N'fileToICBS', N'GLT9093AAF.MBR')
INSERT [dbo].[DIDR_ConfigurationData] ([idx], [config_name], [config_value]) VALUES (7, N'ppkpath', N'c:\ssh\u_aaf_sftp.ppk')
INSERT [dbo].[DIDR_ConfigurationData] ([idx], [config_name], [config_value]) VALUES (8, N'convertto', N'ebcdic')
INSERT [dbo].[DIDR_ConfigurationData] ([idx], [config_name], [config_value]) VALUES (9, N'codepage', N'IBM037')
INSERT [dbo].[DIDR_ConfigurationData] ([idx], [config_name], [config_value]) VALUES (10, N'crlf', N'false')
INSERT [dbo].[DIDR_ConfigurationData] ([idx], [config_name], [config_value]) VALUES (11, N'skipbytesforcrlf', N'250')
INSERT [dbo].[DIDR_ConfigurationData] ([idx], [config_name], [config_value]) VALUES (12, N'sourcefilenametoSFTP', N'C:\DIDR\Interface\procFolder')
INSERT [dbo].[DIDR_ConfigurationData] ([idx], [config_name], [config_value]) VALUES (13, N'hostname', N'BDOAS001.ho.ad.bdo')
INSERT [dbo].[DIDR_ConfigurationData] ([idx], [config_name], [config_value]) VALUES (14, N'username', N'p_aaf_ft')
INSERT [dbo].[DIDR_ConfigurationData] ([idx], [config_name], [config_value]) VALUES (15, N'password', N'')
INSERT [dbo].[DIDR_ConfigurationData] ([idx], [config_name], [config_value]) VALUES (16, N'portnumber', N'22')
INSERT [dbo].[DIDR_ConfigurationData] ([idx], [config_name], [config_value]) VALUES (17, N'ftpICBSFilePath', N'/QSYS.LIB/B1BLFDTA11.LIB/GLT9093AAF.FILE/GLT9093AAF.MBR')
INSERT [dbo].[DIDR_ConfigurationData] ([idx], [config_name], [config_value]) VALUES (18, N'ftpSSHFingerPrint', N'ssh-ed25519 256 91:79:13:d4:67:35:bb:12:5a:33:14:e2:ec:75:02:5c')
INSERT [dbo].[DIDR_ConfigurationData] ([idx], [config_name], [config_value]) VALUES (19, N'scheduledTimeForUpload', N'1:45 AM')
INSERT [dbo].[DIDR_ConfigurationData] ([idx], [config_name], [config_value]) VALUES (20, N'TimeToPostNewRecord', N'1:55 AM')
INSERT [dbo].[DIDR_ConfigurationData] ([idx], [config_name], [config_value]) VALUES (20, N'includeBDOLFS', N'Yes')
INSERT [dbo].[DIDR_ConfigurationData] ([idx], [config_name], [config_value]) VALUES (20, N'includeBDORIS', N'No')
SET IDENTITY_INSERT [dbo].[DIDR_ConfigurationData] OFF


---------------**************************************************************

--*****************************
--  CREATION OF STORED PROCEDURE AND MODIFICATION OF TABLE
--*****************************
IF EXISTS(SELECT * FROM information_schema.columns  where table_name = N'Foreign Currency' and column_name = N'd_lastUpdated')
	ALTER TABLE [Foreign Currency] DROP COLUMN d_lastUpdated
GO 
	ALTER TABLE [Foreign Currency] ADD d_lastUpdated nvarchar(max) null
	--select * from [Foreign Currency] 
GO
---------------

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DIDR_ForeignCurrency]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[DIDR_ForeignCurrency]
GO
CREATE procedure DIDR_ForeignCurrency   
 @startDate datetime,    
 @endDate datetime,  
 @name nvarchar(max) OUTPUT    
AS    
begin    
 set @name = 'ForeignCurrency'  
 Select 
	tbl= @name,
	C_CURRENCY,
	C_CURRCODE
 from ForeignCurrency    
end    
-- exec DIDR_RoleReference '06/01/2016', '06/30/2016',''    
-------------------------------------------------------
GO
---------------
IF EXISTS(SELECT * FROM information_schema.columns  where table_name = N'BankCharges' and column_name = N'd_lastUpdated')
	ALTER TABLE BankCharges DROP COLUMN d_lastUpdated
GO 
	ALTER TABLE BankCharges ADD d_lastUpdated nvarchar(max) null
GO
---------------
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DIDR_BankCharges]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[DIDR_BankCharges   ]
GO

CREATE procedure DIDR_BankCharges   
 @startDate datetime,    
 @endDate datetime,  
 @name nvarchar(max) OUTPUT    
AS    
begin    

 set @name = 'BankCharges'  
 Select 
	tbl= @name, 
	C_CLNTCODE,
	N_BANKCHARGES,
	D_EFFDATE
 from BankCharges    
end    
-- exec DIDR_RoleReference '06/01/2016', '06/30/2016',''    
-------------------------------------------------------
GO
---------------
IF EXISTS(SELECT * FROM information_schema.columns  where table_name = N'BorrowingTransaction' and column_name = N'd_lastUpdated')
	ALTER TABLE BorrowingTransaction DROP COLUMN d_lastUpdated
GO 
	ALTER TABLE BorrowingTransaction ADD d_lastUpdated nvarchar(max) null
GO
---------------

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DIDR_BorrowingTransaction]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[DIDR_BorrowingTransaction]
GO
CREATE procedure DIDR_BorrowingTransaction  
 @startDate datetime,    
 @endDate datetime,  
 @name nvarchar(max) OUTPUT    
AS    
begin    
 set @name = 'BorrowingTransaction'  
 Select 
	tbl= @name,
	N_BORROWID,
	D_TRANDATE,
	C_PDSNO,
	C_FNDRCODE,
	D_VALUDATE,
	C_TRANTYPE,
	N_PRINCPAL,
	N_TERM,
	C_TERMUNIT,
	C_TERMLEN,
	N_INTRATE,
	D_MATDATE,
	L_REPRICE,
	N_TAX,
	C_TAXAPPL,
	C_INTTYPE,
	C_INTAPPL,
	C_PRNPAY,
	N_DAYS,
	N_GRACE,
	N_DOCSTAMP,
	N_TAXAMT,
	N_OTHCHRGS,
	N_TOTALINTEREST,
	N_GROSSINTEREST,
	N_INTEREST,
	N_PVALUE,
	N_PROCEEDS,
	N_MATVALUE,
	C_REMARKS = convert (nvarchar(max), (select convert(varbinary,C_REMARKS ) for XML PATH(''), BINARY BASE64)),
	C_STATUS,
	L_FORCURR,
	N_FOREX,
	D_FOREXDTE,
	C_FORTYPE,
	N_TOTALCHG,
	C_PROTYPE,
	N_PAYOUT,
	N_PAYINT,
	C_PNNOS,
	N_OUTBAL,
	N_PARTPRETERM,
	D_PRETERMDATE,
	N_REBATE,
	C_ACTNGBILL,
	B_ACTNGPROCESS,
	D_STCPDATE,
	N_PREVRATE,
	N_PREVPRINCPAL,
	N_PREVTERM,
	C_PREVTERMUNIT,
	N_PREVMATVALUE,
	C_USERS,
	D_FIRSTDATE,
	D_NEXTDATE,
	C_CHECKEDBY,
	C_APPROVEDBY,
	C_PREPAREDBY,
	B_MATFLAG,
	B_STPNSCHED,
	B_CHANGEPN,
	B_NEWBORROWING,
	C_REFPDSNO,
	C_CASHPOSCODE,
	N_DST,
	N_CWT,
	D_LASTMATURITYDT,
	C_TRANSACTIONSEQ
from BorrowingTransaction    
end    
-- exec DIDR_RoleReference '06/01/2016', '06/30/2016',''    
-------------------------------------------------------
GO
---------------
IF EXISTS(SELECT * FROM information_schema.columns  where table_name = N'Branches' and column_name = N'd_lastUpdated')
	ALTER TABLE Branches DROP COLUMN d_lastUpdated
GO 
	ALTER TABLE Branches ADD d_lastUpdated nvarchar(max) null
GO
---------------

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DIDR_Branches]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[DIDR_Branches]
GO
CREATE procedure DIDR_Branches  
 @startDate datetime,    
 @endDate datetime,  
 @name nvarchar(max) OUTPUT    
AS    
begin    
 set @name = 'Branches'  
 Select 
	tbl= @name,
	C_BRANCODE,
	C_BRANCHNM,
	C_REMARKS =  convert (nvarchar(max), (select convert(varbinary, convert(nvarchar(max), C_REMARKS) ) for XML PATH(''), BINARY BASE64)),
	IDX
from Branches    
end    
-- exec DIDR_RoleReference '06/01/2016', '06/30/2016',''    
-------------------------------------------------------
GO
---------------
IF EXISTS(SELECT * FROM information_schema.columns  where table_name = N'BranchRemit' and column_name = N'd_lastUpdated')
	ALTER TABLE BranchRemit DROP COLUMN d_lastUpdated
GO 
	ALTER TABLE BranchRemit ADD d_lastUpdated nvarchar(max) null
GO
---------------
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DIDR_BranchRemit]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[DIDR_BranchRemit]
GO
CREATE procedure DIDR_BranchRemit
 @startDate datetime,    
 @endDate datetime,  
 @name nvarchar(max) OUTPUT    
AS    
begin    
 set @name = 'BranchRemit'  
 Select 
	tbl= @name, 
	N_BRANCHREMITID,
	C_BRANCH,
	N_AMOUNT,
	D_REMITDATE,
	C_TYPE,
	C_ACCTNAME,
	N_RATE,
	N_TERM,
	C_FACILITY,
	C_ACCTOFFICER,
	C_CASHPOSCODE
from BranchRemit    
end    
-- exec DIDR_RoleReference '06/01/2016', '06/30/2016',''    
-------------------------------------------------------
GO
---------------
IF EXISTS(SELECT * FROM information_schema.columns  where table_name = N'CashPositionAccount' and column_name = N'd_lastUpdated')
	ALTER TABLE CashPositionAccount DROP COLUMN d_lastUpdated
GO 
	ALTER TABLE CashPositionAccount ADD d_lastUpdated nvarchar(max) null
GO
---------------
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DIDR_CashPositionAccount]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[DIDR_CashPositionAccount]
GO
CREATE procedure DIDR_CashPositionAccount
 @startDate datetime,    
 @endDate datetime,  
 @name nvarchar(max) OUTPUT    
AS    
begin    
 set @name = 'CashPositionAccount'  
 Select 
	tbl= @name, 
	C_CASHPOSCODE,
	C_CASHPOSITION
from CashPositionAccount    
end    
-- exec DIDR_RoleReference '06/01/2016', '06/30/2016',''    
----
GO
---------------
IF EXISTS(SELECT * FROM information_schema.columns  where table_name = N'Client' and column_name = N'd_lastUpdated')
	ALTER TABLE Client DROP COLUMN d_lastUpdated
GO 
	ALTER TABLE Client ADD d_lastUpdated nvarchar(max) null
GO
---------------
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DIDR_Client]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[DIDR_Client]
GO
CREATE procedure DIDR_Client
 @startDate datetime,    
 @endDate datetime,  
 @name nvarchar(max) OUTPUT    
AS    
begin    
 set @name = 'Client'  
 Select 
	tbl= @name, 
	C_CLNTCODE,
	C_CLNTNAME,
	C_CLNTCLAS,
	C_INDCODE,
	C_ADDRESS,
	C_PHONE,
	C_FAXNO,
	C_CONTACT,
	C_REFERRAL,
	N_STCRLINE,
	N_LTCRLINE,
	N_OTCRLINE,
	N_PARVALUE,
	C_REMARKS = convert (nvarchar(max), (select convert(varbinary,C_REMARKS ) for XML PATH(''), BINARY BASE64)),
	B_OURBANK,
	D_DATEOFINCORPORATION,
	C_SOURCEOFFUND,
	C_NATUREOFWORK,
	C_DIRECTORS,
	C_CLIENTCLASS,
	TIN,
	MATURITYDATE,
	N_CIFNO

from Client    

-- alter table Client add N_CIFNO varchar(20) null
end    
-- exec DIDR_RoleReference '06/01/2016', '06/30/2016',''    
----
GO
---------------
IF EXISTS(SELECT * FROM information_schema.columns  where table_name = N'CPBRWDET' and column_name = N'd_lastUpdated')
	ALTER TABLE CPBRWDET DROP COLUMN d_lastUpdated
GO 
	ALTER TABLE CPBRWDET ADD d_lastUpdated nvarchar(max) null
GO
---------------
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DIDR_CPBRWDET]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[DIDR_CPBRWDET]
GO
CREATE procedure DIDR_CPBRWDET
 @startDate datetime,    
 @endDate datetime,  
 @name nvarchar(max) OUTPUT    
AS    
begin    
 set @name = 'CPBRWDET'  
 Select 
	tbl= @name, 
	N_CPBRWDETID,
	C_PDSNO,
	C_CLNTCODE,
	C_CPCODE,
	C_CPSRLNO,
	N_CPAMT,
	D_TRANDATE,
	C_AGENT,
	B_EXPIRED,
	B_CPPRINTED,
	D_DATEISSUED,
	N_ISSUEDBY,
	D_DATEPRINTED,
	N_REMARKS = convert (nvarchar(max), (select convert(varbinary,N_REMARKS ) for XML PATH(''), BINARY BASE64)),
	N_COMPUTEDPROCEEDS,
	ISSUINGBATCHNO,
	BATCHNORECORDON,
	BORROWEDBATCHNO,
	D_DATEPURCHASED,
	B_CPTAG,
	N_CPTAGGINGREMARKS =  convert (nvarchar(max), (select convert(varbinary,N_CPTAGGINGREMARKS  ) for XML PATH(''), BINARY BASE64)),
	I_CPSTATUS,
	N_TAGGEDBY,
	D_TAGGEDON,
	N_EVENTHISTORICAL,
	D_RETURNEDBYINVESTOR,
	D_RETURNEDTOSEC,
	D_RETURNEDTOSECBATCHNO,
	LICENSENO
from CPBRWDET    
end    
-- exec DIDR_RoleReference '06/01/2016', '06/30/2016',''    
----
GO
---------------
IF EXISTS(SELECT * FROM information_schema.columns  where table_name = N'CPBRWMST' and column_name = N'd_lastUpdated')
	ALTER TABLE CPBRWMST DROP COLUMN d_lastUpdated
GO 
	ALTER TABLE CPBRWMST ADD d_lastUpdated nvarchar(max) null
GO
---------------
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DIDR_CPBRWMST]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[DIDR_CPBRWMST]
GO
CREATE procedure DIDR_CPBRWMST
 @startDate datetime,    
 @endDate datetime,  
 @name nvarchar(max) OUTPUT    
AS    
begin    
 set @name = 'CPBRWMST'  
 Select 
	tbl= @name, 
	C_PDSNO,
	C_CLNTCODE,
	C_CLNTNAME,
	D_MATDATE,
	D_TRANDATE,
	N_AMOUNT,
	C_REMARKS = convert (nvarchar(max), (select convert(varbinary,C_REMARKS ) for XML PATH(''), BINARY BASE64)),
	C_AGENT,
	C_LICENSE
 from CPBRWMST    
end    
-- exec DIDR_RoleReference '06/01/2016', '06/30/2016',''    
----
GO
---------------
IF EXISTS(SELECT * FROM information_schema.columns  where table_name = N'CPDENOM' and column_name = N'd_lastUpdated')
	ALTER TABLE CPDENOM DROP COLUMN d_lastUpdated
GO 
	ALTER TABLE CPDENOM ADD d_lastUpdated nvarchar(max) null
GO
---------------
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DIDR_CPDENOM]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[DIDR_CPDENOM]
GO
CREATE procedure DIDR_CPDENOM
 @startDate datetime,    
 @endDate datetime,  
 @name nvarchar(max) OUTPUT    
AS    
begin    
 set @name = 'CPDENOM'  
 Select 
	tbl= @name, 
	C_CPCODE,
	C_DENONAME,
	N_CPAMT,
	IDX
from CPDENOM    
end    
-- exec DIDR_RoleReference '06/01/2016', '06/30/2016',''    
----
GO
---------------
IF EXISTS(SELECT * FROM information_schema.columns  where table_name = N'CPONHAND' and column_name = N'd_lastUpdated')
	ALTER TABLE CPONHAND DROP COLUMN d_lastUpdated
GO 
	ALTER TABLE CPONHAND ADD d_lastUpdated nvarchar(max) null
GO
---------------
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DIDR_CPONHAND]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[DIDR_CPONHAND]
GO
CREATE procedure DIDR_CPONHAND
 @startDate datetime,    
 @endDate datetime,  
 @name nvarchar(max) OUTPUT    
AS    
begin    
 set @name = 'CPONHAND'  
 Select 
	tbl= @name, 
	N_CPONHANDID,
	C_CPSRLNO,
	C_CPCODE,
	N_CPAMT,
	D_STOREDDATE,
	N_BATCHNO,
	D_PURCHASEDDATE
from CPONHAND    
end    
-- exec DIDR_RoleReference '06/01/2016', '06/30/2016',''    
----
GO
---------------
IF EXISTS(SELECT * FROM information_schema.columns  where table_name = N'DailyTransactionHistory' and column_name = N'd_lastUpdated')
	ALTER TABLE DailyTransactionHistory DROP COLUMN d_lastUpdated
GO 
	ALTER TABLE DailyTransactionHistory ADD d_lastUpdated nvarchar(max) null
GO
---------------
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DIDR_DailyTransactionHistory]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[DIDR_DailyTransactionHistory]
GO
CREATE procedure DIDR_DailyTransactionHistory
 @startDate datetime,    
 @endDate datetime,  
 @name nvarchar(max) OUTPUT    
AS    
begin    
 set @name = 'DailyTransactionHistory'  
 Select 
	tbl= @name, 
	D_TRANSACTIONDATE,
	C_PSDNO,
	C_FUNDERCODE,
	N_PRINCIPAL,
	N_PARTIALPAYMENT,
	N_INTERESTRATE,
	N_TERM,
	D_REPRICING,
	C_REMARKS = convert (nvarchar(max), (select convert(varbinary,C_REMARKS ) for XML PATH(''), BINARY BASE64)),
	C_CATEGORY,
	C_STATUS,
	C_REFPDSNO,
	N_RESTORATIONPOINT
from DailyTransactionHistory    
end    
-- exec DIDR_RoleReference '06/01/2016', '06/30/2016',''    
----
GO
---------------
IF EXISTS(SELECT * FROM information_schema.columns  where table_name = N'DaysFactor' and column_name = N'd_lastUpdated')
	ALTER TABLE DaysFactor DROP COLUMN d_lastUpdated
GO 
	ALTER TABLE DaysFactor ADD d_lastUpdated nvarchar(max) null
GO
---------------
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DIDR_DaysFactor]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[DIDR_DaysFactor]
GO
CREATE procedure DIDR_DaysFactor
 @startDate datetime,    
 @endDate datetime,  
 @name nvarchar(max) OUTPUT    
AS    
begin    
 set @name = 'DaysFactor'  
 Select 
	tbl= @name, 
	C_DESC,
	N_DAYS
from DaysFactor    
end    
-- exec DIDR_RoleReference '06/01/2016', '06/30/2016',''    
----
GO
---------------
IF EXISTS(SELECT * FROM information_schema.columns  where table_name = N'FormReferenceNet' and column_name = N'd_lastUpdated')
	ALTER TABLE FormReferenceNet DROP COLUMN d_lastUpdated
GO 
	ALTER TABLE FormReferenceNet ADD d_lastUpdated nvarchar(max) null
GO
---------------
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DIDR_FormReferenceNet]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[DIDR_FormReferenceNet]
GO
CREATE procedure DIDR_FormReferenceNet
 @startDate datetime,    
 @endDate datetime,  
 @name nvarchar(max) OUTPUT    
AS    
begin    
 set @name = 'FormReferenceNet'  
 Select 
	tbl= @name, 
	FORMID,
	FORM,
	FORMDESCRIPTION,
	MODULES,
	MODULESNET

 from FormReferenceNet    
end    
-- exec DIDR_RoleReference '06/01/2016', '06/30/2016',''    
----
GO
---------------
IF EXISTS(SELECT * FROM information_schema.columns  where table_name = N'Holidays' and column_name = N'd_lastUpdated')
	ALTER TABLE Holidays DROP COLUMN d_lastUpdated
GO 
	ALTER TABLE Holidays ADD d_lastUpdated nvarchar(max) null
GO
---------------
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DIDR_Holidays]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[DIDR_Holidays]
GO
CREATE procedure DIDR_Holidays
 @startDate datetime,    
 @endDate datetime,  
 @name nvarchar(max) OUTPUT    
AS    
begin    
 set @name = 'Holidays'  
 Select 
	tbl= @name, 
	HOLIDAY,
	REASON = convert (nvarchar(max), (select convert(varbinary,REASON ) for XML PATH(''), BINARY BASE64)),
	IDX,
	DATEOFHOLIDAY,
	STATUS,
	COMMENTS

from Holidays    
end    
-- exec DIDR_RoleReference '06/01/2016', '06/30/2016',''    
----
GO
---------------
IF EXISTS(SELECT * FROM information_schema.columns  where table_name = N'InterestApplication' and column_name = N'd_lastUpdated')
	ALTER TABLE InterestApplication DROP COLUMN d_lastUpdated
GO 
	ALTER TABLE InterestApplication ADD d_lastUpdated nvarchar(max) null
GO
---------------
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DIDR_InterestApplication]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[DIDR_InterestApplication]
GO
CREATE procedure DIDR_InterestApplication
 @startDate datetime,    
 @endDate datetime,  
 @name nvarchar(max) OUTPUT    
AS    
begin    
 set @name = 'InterestApplication'  
 Select 
	tbl= @name, 
	INTERESTAPP,
	INTERESTAPPCODE
 from InterestApplication    
end    
-- exec DIDR_RoleReference '06/01/2016', '06/30/2016',''    
----
GO
---------------
IF EXISTS(SELECT * FROM information_schema.columns  where table_name = N'InterestType' and column_name = N'd_lastUpdated')
	ALTER TABLE InterestType DROP COLUMN d_lastUpdated
GO 
	ALTER TABLE InterestType ADD d_lastUpdated nvarchar(max) null
GO
---------------
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DIDR_InterestType]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[DIDR_InterestType]
GO
CREATE procedure DIDR_InterestType
 @startDate datetime,    
 @endDate datetime,  
 @name nvarchar(max) OUTPUT    
AS    
begin    
 set @name = 'InterestType'  
 Select 
	tbl= @name, 
	INTERESTTYPE,
	INTERESTCODE
 from InterestType    
end    
-- exec DIDR_RoleReference '06/01/2016', '06/30/2016',''    
----
GO
---------------
IF EXISTS(SELECT * FROM information_schema.columns  where table_name = N'LASTPDS' and column_name = N'd_lastUpdated')
	ALTER TABLE LASTPDS DROP COLUMN d_lastUpdated
GO 
	ALTER TABLE LASTPDS ADD d_lastUpdated nvarchar(max) null
GO
---------------
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DIDR_LASTPDS]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[DIDR_LASTPDS]
GO
CREATE procedure DIDR_LASTPDS
 @startDate datetime,    
 @endDate datetime,  
 @name nvarchar(max) OUTPUT    
AS    
begin    
 set @name = 'LASTPDS'  
 Select tbl= @name, C_LASTPDS from LASTPDS    
end    
-- exec DIDR_RoleReference '06/01/2016', '06/30/2016',''    
----
GO
---------------
IF EXISTS(SELECT * FROM information_schema.columns  where table_name = N'MenuSideBar' and column_name = N'd_lastUpdated')
	ALTER TABLE MenuSideBar DROP COLUMN d_lastUpdated
GO 
	ALTER TABLE MenuSideBar ADD d_lastUpdated nvarchar(max) null
GO
---------------
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DIDR_MenuSideBar]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[DIDR_MenuSideBar]
GO
CREATE procedure DIDR_MenuSideBar
 @startDate datetime,    
 @endDate datetime,  
 @name nvarchar(max) OUTPUT    
AS    
begin    
 set @name = 'MenuSideBar'  
 Select 
	tbl= @name, 
	ID,
	CODE,
	NAME,
	[GROUP],
	FORMID,
	ROLEID,
	PRINTACCESS
 from MenuSideBar    
end    
-- exec DIDR_RoleReference '06/01/2016', '06/30/2016',''    
----
GO
---------------
IF EXISTS(SELECT * FROM information_schema.columns  where table_name = N'MenusSideBar' and column_name = N'd_lastUpdated')
	ALTER TABLE MenusSideBar DROP COLUMN d_lastUpdated
GO 
	ALTER TABLE MenusSideBar ADD d_lastUpdated nvarchar(max) null
GO
---------------
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DIDR_MenusSideBar]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[DIDR_MenusSideBar]
GO
CREATE procedure DIDR_MenusSideBar
 @startDate datetime,    
 @endDate datetime,  
 @name nvarchar(max) OUTPUT    
AS    
begin    
 set @name = 'MenusSideBar'  
 Select 
	tbl= @name, 
	*
 from MenusSideBar    
end    
-- exec DIDR_RoleReference '06/01/2016', '06/30/2016',''    
----
GO
---------------
IF EXISTS(SELECT * FROM information_schema.columns  where table_name = N'Miscellaneous' and column_name = N'd_lastUpdated')
	ALTER TABLE Miscellaneous DROP COLUMN d_lastUpdated
GO 
	ALTER TABLE Miscellaneous ADD d_lastUpdated nvarchar(max) null
GO
---------------
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DIDR_Miscellaneous]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[DIDR_Miscellaneous]
GO
CREATE procedure DIDR_Miscellaneous
 @startDate datetime,    
 @endDate datetime,  
 @name nvarchar(max) OUTPUT    
AS    
begin    
 set @name = 'Miscellaneous'  
 Select 
	tbl= @name, 
	 C_DESC,
	N_AMOUNT,
	N_INTERESTRATE,
	C_TERM,
	C_GROUP,
	N_TYPE,
	D_DATE,
	C_GDESC,
	C_TDESC,
	C_CASHPOSCODE

 from Miscellaneous    
end    
-- exec DIDR_RoleReference '06/01/2016', '06/30/2016',''    
----
GO
---------------
IF EXISTS(SELECT * FROM information_schema.columns  where table_name = N'MiscellaneousType' and column_name = N'd_lastUpdated')
	ALTER TABLE MiscellaneousType DROP COLUMN d_lastUpdated
GO 
	ALTER TABLE MiscellaneousType ADD d_lastUpdated nvarchar(max) null
GO
---------------
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DIDR_MiscellaneousType]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[DIDR_MiscellaneousType]
GO
CREATE procedure DIDR_MiscellaneousType
 @startDate datetime,    
 @endDate datetime,  
 @name nvarchar(max) OUTPUT    
AS    
begin    
 set @name = 'MiscellaneousType'  
 Select 
	tbl= @name,
	IDX,
	CODE,
	DESCRIPTION
 from MiscellaneousType    
end    
-- exec DIDR_RoleReference '06/01/2016', '06/30/2016',''    
----
GO
---------------
IF EXISTS(SELECT * FROM information_schema.columns  where table_name = N'PaidTran' and column_name = N'd_lastUpdated')
	ALTER TABLE PaidTran DROP COLUMN d_lastUpdated
GO 
	ALTER TABLE PaidTran ADD d_lastUpdated nvarchar(max) null
GO
---------------
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DIDR_PaidTran]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[DIDR_PaidTran]
GO
CREATE procedure DIDR_PaidTran
 @startDate datetime,    
 @endDate datetime,  
 @name nvarchar(max) OUTPUT    
AS    
begin    
 set @name = 'PaidTran'  
 Select 
	tbl= @name, 
	N_PAIDTRANID,
	C_PDSNO,
	C_FNDRCODE,
	N_AMT,
	N_INTRATE,
	D_TRANDATE,
	N_TERM,
	C_TYPE,
	C_REMARKS = convert (nvarchar(max), (select convert(varbinary,   convert(nvarchar(max), C_REMARKS) ) for XML PATH(''), BINARY BASE64)),
	L_FORCURR
from PaidTran    
end    
-- exec DIDR_RoleReference '06/01/2016', '06/30/2016',''    
----
GO
---------------
IF EXISTS(SELECT * FROM information_schema.columns  where table_name = N'ParameterSettings' and column_name = N'd_lastUpdated')
	ALTER TABLE ParameterSettings DROP COLUMN d_lastUpdated
GO 
	ALTER TABLE ParameterSettings ADD d_lastUpdated nvarchar(max) null
GO
---------------
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DIDR_ParameterSettings]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[DIDR_ParameterSettings]
GO
CREATE procedure DIDR_ParameterSettings
 @startDate datetime,    
 @endDate datetime,  
 @name nvarchar(max) OUTPUT    
AS    
begin    
 set @name = 'ParameterSettings'  
 Select 
	tbl= @name, 
	N_USERIDMIN,
	N_USERIDMAX,
	C_DEFAULTPASS,
	N_PASSMIN,
	N_ALLOWINVALIDPASS,
	N_PASSEXPIRED,
	N_PASSWARNING,
	N_PASSHISTORY,
	N_INACTIVE,
	N_DISABLED,
	N_PURGED,
	IDLE_MIN
from ParameterSettings    
end    
-- exec DIDR_RoleReference '06/01/2016', '06/30/2016',''    
----
GO
---------------
IF EXISTS(SELECT * FROM information_schema.columns  where table_name = N'PDSAcctEntries' and column_name = N'd_lastUpdated')
	ALTER TABLE PDSAcctEntries DROP COLUMN d_lastUpdated
GO 
	ALTER TABLE PDSAcctEntries ADD d_lastUpdated nvarchar(max) null
GO
--------------------
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DIDR_PDSAcctEntries]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[DIDR_PDSAcctEntries]
GO
CREATE procedure DIDR_PDSAcctEntries
 @startDate datetime,    
 @endDate datetime,  
 @name nvarchar(max) OUTPUT    
AS    
begin    
 set @name = 'PDSAcctEntries'  
 Select 
	tbl= @name, 
	C_PDSNO,
	C_ACCTCODE,
	N_DEBIT,
	N_CREDIT,
	N_ADJCODE,
	N_REFPDS,
	B_PROCESSED,
	D_PROCESSED,
	C_PROCESSEDBY,
	C_ENTRYTYPE,
	D_TRANDATE

from PDSAcctEntries    
end    
-- exec DIDR_RoleReference '06/01/2016', '06/30/2016',''    
----
GO
---------------
IF EXISTS(SELECT * FROM information_schema.columns  where table_name = N'PDSCopy' and column_name = N'd_lastUpdated')
	ALTER TABLE PDSCopy DROP COLUMN d_lastUpdated
GO 
	ALTER TABLE PDSCopy ADD d_lastUpdated nvarchar(max) null
GO
----------------
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DIDR_PDSCopy]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[DIDR_PDSCopy]
GO
CREATE procedure DIDR_PDSCopy
 @startDate datetime,    
 @endDate datetime,  
 @name nvarchar(max) OUTPUT    
AS    
begin    
 set @name = 'PDSCopy'  
 Select tbl= @name, C_PDSNO, C_COPY from PDSCopy    
end    
-- exec DIDR_RoleReference '06/01/2016', '06/30/2016',''    
----
GO
---------------
IF EXISTS(SELECT * FROM information_schema.columns  where table_name = N'PDSTransfer' and column_name = N'd_lastUpdated')
	ALTER TABLE PDSTransfer DROP COLUMN d_lastUpdated
GO 
	ALTER TABLE PDSTransfer ADD d_lastUpdated nvarchar(max) null
GO
----------------
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DIDR_PDSTransfer]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[DIDR_PDSTransfer]
GO
CREATE procedure DIDR_PDSTransfer
 @startDate datetime,    
 @endDate datetime,  
 @name nvarchar(max) OUTPUT    
AS    
begin    
 set @name = 'PDSTransfer'  
 Select 
	tbl= @name, 
	C_PDSNO,
	C_FNDRCODE,
	C_ENTRYTYPE,
	C_TRANTYPE,
	B_PROCESSED,
	D_PROCESSED,
	C_PROCESSEDBY,
	D_TRANDATE,
	C_MAKER
 from PDSTransfer    
end    
-- exec DIDR_RoleReference '06/01/2016', '06/30/2016',''    
----
GO
---------------
IF EXISTS(SELECT * FROM information_schema.columns  where table_name = N'PlaceType' and column_name = N'd_lastUpdated')
	ALTER TABLE PlaceType DROP COLUMN d_lastUpdated
GO 
	ALTER TABLE PlaceType ADD d_lastUpdated nvarchar(max) null
GO
----------------
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DIDR_PlaceType]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[DIDR_PlaceType]
GO
CREATE procedure DIDR_PlaceType
 @startDate datetime,    
 @endDate datetime,  
 @name nvarchar(max) OUTPUT    
AS    
begin    
 set @name = 'PlaceType'  
 Select 
	tbl= @name, 
	C_TYPE,
	C_CODE
 from PlaceType    
end    
-- exec DIDR_RoleReference '06/01/2016', '06/30/2016',''    
----
GO
---------------
IF EXISTS(SELECT * FROM information_schema.columns  where table_name = N'PNCPExpiry' and column_name = N'd_lastUpdated')
	ALTER TABLE PNCPExpiry DROP COLUMN d_lastUpdated
GO 
	ALTER TABLE PNCPExpiry ADD d_lastUpdated nvarchar(max) null
GO
----------------
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DIDR_PNCPExpiry]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[DIDR_PNCPExpiry]
GO
CREATE procedure DIDR_PNCPExpiry
 @startDate datetime,    
 @endDate datetime,  
 @name nvarchar(max) OUTPUT    
AS    
begin    
 set @name = 'PNCPExpiry'  
 Select 
	tbl= @name, 
	C_PDSNO,
	C_PNNOS,
	D_DATEBOOK,
	D_EXPIRYDATE

 from PNCPExpiry    
end    
-- exec DIDR_RoleReference '06/01/2016', '06/30/2016',''    
----
GO
---------------
IF EXISTS(SELECT * FROM information_schema.columns  where table_name = N'PNLTDET' and column_name = N'd_lastUpdated')
	ALTER TABLE PNLTDET DROP COLUMN d_lastUpdated
GO 
	ALTER TABLE PNLTDET ADD d_lastUpdated nvarchar(max) null
GO
----------------
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DIDR_PNLTDET]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[DIDR_PNLTDET]
GO
CREATE procedure DIDR_PNLTDET
 @startDate datetime,    
 @endDate datetime,  
 @name nvarchar(max) OUTPUT    
AS    
begin    
 set @name = 'PNLTDET'  
 Select 
	tbl= @name, 
	N_PNLTDETID
	C_PDSNO,
	C_FNDRCODE,
	D_FROMDATE,
	D_QDATE,
	N_TERM,
	N_PRNAMORT,
	N_INTAMORT,
	N_TOTAMORT,
	N_BALANCE,
	N_COUNTER,
	L_PAID,
	N_AMTPAID,
	C_TRANTYPE,
	C_PROTYPE,
	N_INTRATE,
	C_AMORTTYPE,
	C_REMARKS = convert (nvarchar(max), (select convert(varbinary,C_REMARKS ) for XML PATH(''), BINARY BASE64)),
	D_PAIDDATE,
	L_FORCURR,
	C_PAIDBY,
	IDX,
	C_CASHPOSCODE

from PNLTDET    
end    
-- exec DIDR_RoleReference '06/01/2016', '06/30/2016',''    
----
GO
---------------
IF EXISTS(SELECT * FROM information_schema.columns  where table_name = N'PNLTMST' and column_name = N'd_lastUpdated')
	ALTER TABLE PNLTMST DROP COLUMN d_lastUpdated
GO 
	ALTER TABLE PNLTMST ADD d_lastUpdated nvarchar(max) null
GO
----------------
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DIDR_PNLTMST]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[DIDR_PNLTMST]
GO
CREATE procedure DIDR_PNLTMST
 @startDate datetime,    
 @endDate datetime,  
 @name nvarchar(max) OUTPUT    
AS    
begin    
 set @name = 'PNLTMST'  
 Select 
	tbl= @name, 
	N_PNLTMSTID,
	C_PDSNO,
	C_FNDRCODE,
	N_PRINCPAL,
	N_INTEREST,
	N_TERM,
	C_TERMUNIT,
	D_VALUDATE,
	D_MATDATE,
	C_REPAYMNT,
	N_GRACE,
	N_INTRATE,
	N_DAYFACT,
	C_PAYTYPE,
	C_TRANTYPE,
	N_MATVALUE,
	N_RATE,
	C_PROTYPE,
	C_REMARKS = convert (varchar(max), (select convert(varbinary, convert(nvarchar(max), C_REMARKS) ) for XML PATH(''), BINARY BASE64)),
	C_INTAPPL,
	C_INTTYPE,
	N_TAX,
	L_FORCURR,
	C_PREPAREDBY
from PNLTMST    
end    
-- exec DIDR_RoleReference '06/01/2016', '06/30/2016',''    
----
GO
---------------
IF EXISTS(SELECT * FROM information_schema.columns  where table_name = N'PrincipalPayment' and column_name = N'd_lastUpdated')
	ALTER TABLE PrincipalPayment DROP COLUMN d_lastUpdated
GO 
	ALTER TABLE PrincipalPayment ADD d_lastUpdated nvarchar(max) null
GO
----------------
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DIDR_PrincipalPayment]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[DIDR_PrincipalPayment]
GO
CREATE procedure DIDR_PrincipalPayment
 @startDate datetime,    
 @endDate datetime,  
 @name nvarchar(max) OUTPUT    
AS    
begin    
 set @name = 'PrincipalPayment'  
 Select 
	tbl= @name, 
	PAYMENTTYPE,
	PAYMENTCODE
from PrincipalPayment    
end    
-- exec DIDR_RoleReference '06/01/2016', '06/30/2016',''    
----
GO
-----------------
--IF EXISTS(SELECT * FROM information_schema.columns  where table_name = N'QPlacementReport' and column_name = N'd_lastUpdated')
--	ALTER TABLE QPlacementReport DROP COLUMN d_lastUpdated
--GO 
--	ALTER TABLE QPlacementReport ADD d_lastUpdated nvarchar(max) null
--GO
------select * from QPlacementReport
------------------
--IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DIDR_QPlacementReport]') AND type in (N'P', N'PC'))
--DROP PROCEDURE [dbo].[DIDR_QPlacementReport]
--GO
--CREATE procedure DIDR_QPlacementReport
-- @startDate datetime,    
-- @endDate datetime,  
-- @name nvarchar(max) OUTPUT    
--AS    
--begin    
-- set @name = 'QPlacementReport'  
-- Select 
--	tbl= @name, 
--	D_VALUDATE,
--	C_CLNTNAME,
--	N_PRINCPAL,
--	C_PROTYPE,
--	D_MATDATE,
--	C_STATUS,
--	N_TERM,
--	N_INTRATE,
--	VPTYPE,
--	C_TERMUNIT,
--	C_PDSNO,
--	L_FORCURR
--from QPlacementReport    
--end    
-- exec DIDR_RoleReference '06/01/2016', '06/30/2016',''    
----
GO
---------------
IF EXISTS(SELECT * FROM information_schema.columns  where table_name = N'RoleForm' and column_name = N'd_lastUpdated')
	ALTER TABLE RoleForm DROP COLUMN d_lastUpdated
GO 
	ALTER TABLE RoleForm ADD d_lastUpdated nvarchar(max) null
GO
----------------
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DIDR_RoleForm]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[DIDR_RoleForm]
GO
CREATE procedure DIDR_RoleForm
 @startDate datetime,    
 @endDate datetime,  
 @name nvarchar(max) OUTPUT    
AS    
begin    
 set @name = 'RoleForm'  
 Select 
	tbl= @name, 
	ROLEFORMID,
	ROLE,
	ROLEFORM
from RoleForm    
end    
-- exec DIDR_RoleReference '06/01/2016', '06/30/2016',''    
----
GO
---------------
IF EXISTS(SELECT * FROM information_schema.columns  where table_name = N'RolePermission' and column_name = N'd_lastUpdated')
	ALTER TABLE RolePermission DROP COLUMN d_lastUpdated
GO 
	ALTER TABLE RolePermission ADD d_lastUpdated nvarchar(max) null
GO
----------------
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DIDR_RolePermission]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[DIDR_RolePermission]
GO
CREATE procedure DIDR_RolePermission
 @startDate datetime,    
 @endDate datetime,  
 @name nvarchar(max) OUTPUT    
AS    
begin    
 set @name = 'RolePermission'  
 Select 
	tbl= @name, 
	ROLE,
	ACCESS,
	FORM,
	ISALLOWED,
	FRMOBJECT,
	FRMOBJECTIDX
from RolePermission    
end    
-- exec DIDR_RoleReference '06/01/2016', '06/30/2016',''    
GO
---------------
IF EXISTS(SELECT * FROM information_schema.columns  where table_name = N'RolePermissionnet' and column_name = N'd_lastUpdated')
	ALTER TABLE RolePermissionnet DROP COLUMN d_lastUpdated
GO 
	ALTER TABLE RolePermissionnet ADD d_lastUpdated nvarchar(max) null
GO
----------------
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DIDR_RolePermissionnet]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[DIDR_RolePermissionnet]
GO
CREATE procedure DIDR_RolePermissionnet
 @startDate datetime,    
 @endDate datetime,  
 @name nvarchar(max) OUTPUT    
AS    
begin    
 set @name = 'RolePermissionnet'  
 Select 
	tbl= @name, 
	ROLE,
	ACCESS,
	FORM,
	ISALLOWED,
	FRMOBJECT,
	FRMOBJECTIDX
from RolePermissionnet    
end    
-- exec DIDR_RoleReference '06/01/2016', '06/30/2016',''    
----
GO
---------------
IF EXISTS(SELECT * FROM information_schema.columns  where table_name = N'RoleReference' and column_name = N'd_lastUpdated')
	ALTER TABLE RoleReference DROP COLUMN d_lastUpdated
GO 
	ALTER TABLE RoleReference ADD d_lastUpdated nvarchar(max) null
GO
----------------
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DIDR_RoleReference]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[DIDR_RoleReference]
GO
CREATE procedure DIDR_RoleReference
 @startDate datetime,    
 @endDate datetime,  
 @name nvarchar(max) OUTPUT    
AS    
begin    
 set @name = 'RoleReference'  
 Select 
	tbl= @name, 
	ROLE,
	ROLEDESC,
	USERDEPARTMENTCODE,
	RANKING
from RoleReference    
end    
-- exec DIDR_RoleReference '06/01/2016', '06/30/2016',''    
----
GO
---------------
IF EXISTS(SELECT * FROM information_schema.columns  where table_name = N'rollover' and column_name = N'd_lastUpdated')
	ALTER TABLE rollover DROP COLUMN d_lastUpdated
GO 
	ALTER TABLE rollover ADD d_lastUpdated nvarchar(max) null
GO
----------------
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DIDR_rollover]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[DIDR_rollover]
GO
CREATE procedure DIDR_rollover
 @startDate datetime,    
 @endDate datetime,  
 @name nvarchar(max) OUTPUT    
AS    
begin    
 set @name = 'rollover'  
 Select 
	tbl= @name, 
	D_TRANDATE,
	C_PDSNO,
	C_FNDRCODE,
	D_VALUDATE,
	C_TRANTYPE,
	N_PRINCPAL,
	N_TERM,
	C_TERMUNIT,
	C_TERMLEN,
	N_INTRATE,
	D_MATDATE,
	L_REPRICE,
	N_TAX,
	C_TAXAPPL,
	C_INTTYPE,
	C_INTAPPL,
	C_PRNPAY,
	N_DAYS,
	N_GRACE,
	N_DOCSTAMP,
	N_TAXAMT,
	N_OTHCHRGS,
	N_INTEREST,
	N_TOTALINTEREST,
	N_PVALUE,
	N_PROCEEDS,
	N_MATVALUE,
	C_REMARKS = convert (nvarchar(max), (select convert(varbinary,C_REMARKS ) for XML PATH(''), BINARY BASE64)),
	C_STATUS,
	L_FORCURR,
	N_FOREX,
	D_FOREXDTE,
	C_FORTYPE,
	N_TOTALCHG,
	C_PROTYPE,
	C_REFPDS,
	N_PAYOUT,
	N_PAYINT,
	D_ROLLEDWHEN,
	C_PNNOS,
	N_PARTPRETERM,
	C_CHECKEDBY,
	C_MODIFIEDBY,
	C_ROLLEDBY,
	C_MATUREDBY,
	C_CASHPOSCODE

from rollover    
end    
-- exec DIDR_RoleReference '06/01/2016', '06/30/2016',''    
----
GO
---------------
IF EXISTS(SELECT * FROM information_schema.columns  where table_name = N'SystemParam' and column_name = N'd_lastUpdated')
	ALTER TABLE SystemParam DROP COLUMN d_lastUpdated
GO 
	ALTER TABLE SystemParam ADD d_lastUpdated nvarchar(max) null
GO
----------------
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DIDR_SystemParam]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[DIDR_SystemParam]
GO
CREATE procedure DIDR_SystemParam
 @startDate datetime,    
 @endDate datetime,  
 @name nvarchar(max) OUTPUT    
AS    
begin    
 set @name = 'SystemParam'  
 Select 
	tbl= @name, 
	N_SYSTEMPARAMID,
	C_SIG1,
	C_SIGPOS1,
	C_SIG2,
	C_SIGPOS2,
	C_SIG3,
	C_SIGPOS3,
	N_STCP,
	N_STPN,
	N_LTCP,
	N_LTPN,
	C_SECCERTAUTHNO,
	C_DEBTCEILING,
	C_PRESIDENT,
	N_CPLINE,
	N_DOLLARRATE,
	DATEISSUED,
	OFFERPERIOD,
	BOARDRESOLUTIONNO,
	DULYAUTHORIZEDOFFICER,
	COMPANYNAME,
	ANNUALDAYS,
	CPINVENTORYPREPAREDBY,
	CPINVENTORYAPPROVEDBY,
	BSPSIG1,
	BSPSIG2,
	VICEPRESIDENT,
	FIRSTVICEPRESIDENT

from SystemParam    
end    
-- exec DIDR_RoleReference '06/01/2016', '06/30/2016',''    
----
GO
---------------
IF EXISTS(SELECT * FROM information_schema.columns  where table_name = N'TaxApplication' and column_name = N'd_lastUpdated')
	ALTER TABLE TaxApplication DROP COLUMN d_lastUpdated
GO 
	ALTER TABLE TaxApplication ADD d_lastUpdated nvarchar(max) null
GO
----------------
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DIDR_TaxApplication]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[DIDR_TaxApplication]
GO
CREATE procedure DIDR_TaxApplication
 @startDate datetime,    
 @endDate datetime,  
 @name nvarchar(max) OUTPUT    
AS    
begin    
 set @name = 'TaxApplication'  
 Select 
	tbl= @name, 
	TAXTYPE,
	TAXCODE
from TaxApplication    
end    
-- exec DIDR_RoleReference '06/01/2016', '06/30/2016',''    
----
GO
---------------
IF EXISTS(SELECT * FROM information_schema.columns  where table_name = N'Terms' and column_name = N'd_lastUpdated')
	ALTER TABLE Terms DROP COLUMN d_lastUpdated
GO 
	ALTER TABLE Terms ADD d_lastUpdated nvarchar(max) null
GO
----------------
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DIDR_Terms]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[DIDR_Terms]
GO
CREATE procedure DIDR_Terms
 @startDate datetime,    
 @endDate datetime,  
 @name nvarchar(max) OUTPUT    
AS    
begin    
 set @name = 'Terms'  
 Select 
	tbl= @name, 
	C_DESCRIPTION,
	C_TYPE
	from Terms    
end    
-- exec DIDR_RoleReference '06/01/2016', '06/30/2016',''    
----
GO
---------------
IF EXISTS(SELECT * FROM information_schema.columns  where table_name = N'TransactionStatus' and column_name = N'd_lastUpdated')
	ALTER TABLE TransactionStatus DROP COLUMN d_lastUpdated
GO 
	ALTER TABLE TransactionStatus ADD d_lastUpdated nvarchar(max) null
GO
----------------
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DIDR_TransactionStatus]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[DIDR_TransactionStatus]
GO
CREATE procedure DIDR_TransactionStatus
 @startDate datetime,    
 @endDate datetime,  
 @name nvarchar(max) OUTPUT    
AS    
begin    
 set @name = 'TransactionStatus'  
 Select 
	tbl= @name, 
	ID,
	CODE,
	NAME
from TransactionStatus    
end    
-- exec DIDR_RoleReference '06/01/2016', '06/30/2016',''    
----
GO
---------------
IF EXISTS(SELECT * FROM information_schema.columns  where table_name = N'TranType' and column_name = N'd_lastUpdated')
	ALTER TABLE TranType DROP COLUMN d_lastUpdated
GO 
	ALTER TABLE TranType ADD d_lastUpdated nvarchar(max) null
GO
----------------
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DIDR_TranType]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[DIDR_TranType]
GO
CREATE procedure DIDR_TranType
 @startDate datetime,    
 @endDate datetime,  
 @name nvarchar(max) OUTPUT    
AS    
begin    
 set @name = 'TranType'  
 Select 
	tbl= @name,
	C_TYPE,
	C_DESCRIPTION
from TranType    
end    
-- exec DIDR_RoleReference '06/01/2016', '06/30/2016',''    
----
GO
---------------
IF EXISTS(SELECT * FROM information_schema.columns  where table_name = N'UserDepartment' and column_name = N'd_lastUpdated')
	ALTER TABLE UserDepartment DROP COLUMN d_lastUpdated
GO 
	ALTER TABLE UserDepartment ADD d_lastUpdated nvarchar(max) null
GO
----------------
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DIDR_UserDepartment]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[DIDR_UserDepartment]
GO
CREATE procedure DIDR_UserDepartment
 @startDate datetime,    
 @endDate datetime,  
 @name nvarchar(max) OUTPUT    
AS    
begin    
 set @name = 'UserDepartment'  
 Select 
	tbl= @name, 
	ID,
	GROUPCODE,
	DESCRIPTION,
	DEFINITION
from UserDepartment    
end    
-- exec DIDR_RoleReference '06/01/2016', '06/30/2016',''    
----
GO
---------------
IF EXISTS(SELECT * FROM information_schema.columns  where table_name = N'Users' and column_name = N'd_lastUpdated')
	ALTER TABLE Users DROP COLUMN d_lastUpdated
GO 
	ALTER TABLE Users ADD d_lastUpdated nvarchar(max) null
GO
----------------
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DIDR_Users]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[DIDR_Users]
GO
CREATE procedure DIDR_Users
 @startDate datetime,    
 @endDate datetime,  
 @name nvarchar(max) OUTPUT    
AS    
begin    
 set @name = 'Users'  
 Select 
	tbl= @name, 
	C_USERNAME,
	C_NAME,
	N_ACCESSLEVEL,
	D_DATECREATED,
	B_LOGGEDON,
	ATTEMPTS,
	EFFDATE,
	C_STATUS,
	D_LASTLOGIN
from Users    
end    
-- exec DIDR_RoleReference '06/01/2016', '06/30/2016',''    
----
GO
---------------
IF EXISTS(SELECT * FROM information_schema.columns  where table_name = N'INDTYPE' and column_name = N'd_lastUpdated')
	ALTER TABLE INDTYPE DROP COLUMN d_lastUpdated
GO 
	ALTER TABLE INDTYPE ADD d_lastUpdated nvarchar(max) null
GO
----------------
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DIDR_INDTYPE]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[DIDR_INDTYPE]
GO
CREATE procedure DIDR_INDTYPE
 @startDate datetime,    
 @endDate datetime,  
 @name nvarchar(max) OUTPUT    
AS    
begin    
 set @name = 'INDTYPE'  
 Select 
	tbl= @name, 
	C_INDCODE,
	C_INDDESC
from INDTYPE    
end    
-- exec DIDR_RoleReference '06/01/2016', '06/30/2016',''    
----
GO
---------------
IF EXISTS(SELECT * FROM information_schema.columns  where table_name = N'CLASCODE' and column_name = N'd_lastUpdated')
	ALTER TABLE CLASCODE DROP COLUMN d_lastUpdated
GO 
	ALTER TABLE CLASCODE ADD d_lastUpdated nvarchar(max) null
GO
----------------
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DIDR_CLASCODE]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[DIDR_CLASCODE]
GO
CREATE procedure DIDR_CLASCODE
 @startDate datetime,    
 @endDate datetime,  
 @name nvarchar(max) OUTPUT    
AS    
begin    
 set @name = 'CLASCODE'  
 Select tbl= @name, 
	C_CLASCODE,
	C_CLASDESC
 from CLASCODE    
end    
-- exec DIDR_RoleReference '06/01/2016', '06/30/2016',''    
----


