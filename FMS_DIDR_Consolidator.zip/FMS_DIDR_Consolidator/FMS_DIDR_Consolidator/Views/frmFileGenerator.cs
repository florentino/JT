﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace FMS_DIDR_Consolidator
{
    public partial class frmFileGenerator : Form
    {
        public frmFileGenerator()
        {
            InitializeComponent();
        }

        public static string filepath = @"C:\DIDR Report\";
        public static string tblName = string.Empty;

        private void btn_print_Click(object sender, EventArgs e)
        {
            try
            {
                string startdt = dtp_startdate.Value.ToShortDateString();
                string enddt = dtp_enddate.Value.ToShortDateString();
                string sqlCmd = "exec DIDR_Tables_allSP '" + startdt + "', '" + enddt + "'";
                DataSet ds = Commons.executeQuery(sqlCmd);
                //tblName =  ds.Tables[0].Rows[0]["tbl"].ToString();
                    write(ds, filepath);
                            }
            catch(Exception ex)
            {
                MessageBox.Show("" + ex);
            }
        }
         private void write(DataSet ds, string filePath)
        {
            try
            {
                string extname = ".TSV";
                //string filename = tblName.ToString().Trim() + @"_"+ DateTime.Now.ToString("yyyyMMddHHmmss");
                int xx = ds.Tables.Count;
                int cnt = 1;
                int ctr = 0;

                foreach (DataTable dt in ds.Tables)
                {
                    tblName = ds.Tables[ctr].Rows[0]["tbl"].ToString();
                    string filename = @"04FM_" + tblName.ToString().Trim() + @"_" + DateTime.Now.ToString("yyyyMMdd");
                    //string filename = @"04FM_" + tblName.ToString().Trim() + @"_" + DateTime.Now.ToString("yyyyMMddHHmmss");
                    //string fullpath = filePath + filename + cnt.ToString() + extname;
                    string fullpath = filePath + filename + extname;
                    using (StreamWriter swrite = new StreamWriter(fullpath))
                    {
                        foreach (DataRow row in dt.Rows)
                        {
                            int i = dt.Columns.Count;

                            for (int x = 0; x < i; x++)
                            {
                                if (!Convert.IsDBNull(row[x]))
                                {
                                    System.Console.Write(row[x].ToString());
                                    if (x > 0) { 
                                        swrite.Write(row[x].ToString());
                                    }
                                }
                                if (x < i - 1)
                                {
                                    if (x > 0) 
                                    {
                                        swrite.Write("\t");
                                    }
                                }
                            }
                            swrite.Write(swrite.NewLine);
                        }
                    }
                    ctr = ctr + 1;
                    cnt = cnt + 1;
                }
                MessageBox.Show("The file has been saved in: " + filePath);
            }
            catch (Exception e)
            {
                MessageBox.Show("Error on writing in .TSV: " + e);
            }

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            if (!Directory.Exists(filepath))
            {
                Directory.CreateDirectory(filepath);
            }
        }
    }
}
