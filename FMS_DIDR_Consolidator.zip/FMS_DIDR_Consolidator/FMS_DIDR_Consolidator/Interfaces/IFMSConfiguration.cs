﻿using FMS_DIDR_Consolidator.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FMS_DIDR_Consolidator.Interfaces
{
    interface IFMSConfiguration
    {
        bool UpdateConsolidator(FMSConfiguration fmsConfig);
        List<FMSConfiguration> GetConfiguration();
    }
}
