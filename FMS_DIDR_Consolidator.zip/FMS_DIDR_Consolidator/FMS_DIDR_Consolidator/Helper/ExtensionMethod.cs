﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FMS_DIDR_Consolidator.Helper
{
    public static class ExtensionMethod
    {
        public static DataTable ToDataTableFromArray<T>(this T[] arr)
        {
            if (arr == null || arr.Length == 0) return null;
            DataTable table = new DataTable();
            var val_tmp = arr[0];
            table.Columns.AddRange(val_tmp.GetType().GetFields().Select(field => new DataColumn(field.Name, field.FieldType)).ToArray());
            int fieldCount = val_tmp.GetType().GetFields().Count();
            arr.All(student =>
            {
                table.Rows.Add(Enumerable.Range(0, fieldCount).Select(index => student.GetType().GetFields()[index].GetValue(student)).ToArray());
                return true;
            });
            return table;
        }
    }
}
