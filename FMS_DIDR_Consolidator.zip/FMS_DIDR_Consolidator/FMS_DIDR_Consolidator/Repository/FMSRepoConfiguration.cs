﻿using FMS_DIDR_Consolidator.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FMS_DIDR_Consolidator.Model;
using System.Data;
using System.Data.SqlClient;

namespace FMS_DIDR_Consolidator.Repository
{
    public class FMSRepoConfiguration : IFMSConfiguration, IDisposable
    {
       
        public List<FMSConfiguration> GetConfiguration()
        {
           List<FMSConfiguration> fmsConfigData = new List<FMSConfiguration>();
            DataTable dt;
            using (SqlConnection conn = new SqlConnection(Commons.executeQuery()))
            {
                conn.Open();

                SqlCommand cmd = new SqlCommand(conn, conn);

                cmd.CommandType = CommandType.Text;
                using (SqlDataReader rdr = cmd.ExecuteReader())
                {
                   dt  = new DataTable();
                    dt.Load(rdr);
                }
                conn.Close();
            }

            //use SP
            //var query = "SELECT config_name, config_value FROM DIDR_ConfigurationData";

            //var data = Commons.executeQuery(query).Tables[0].AsEnumerable();
            
            //foreach (var item in data)
            //{
            //    fmsConfigData.Add(item));
            //}

           // return data.ToList();
        }

        public bool UpdateConsolidator(Model.FMSConfiguration fmsConfig)
        {
            throw new NotImplementedException();
        }

        private bool disposed = false;

        protected virtual void Dispose(bool disposing)
        {
            if (!this.disposed)
            {
                if (disposing)
                {
                    //context.Dispose();
                }
            }
            this.disposed = true;
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
    }
}
