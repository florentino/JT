declare @source varchar(50) = 'The @#$@#	' + char(13)
declare @encoded varchar(500) = convert (varchar(500), (select convert(varbinary,@source) for XML PATH(''), BINARY BASE64))
declare @decoded varchar(500) = convert (varchar(500), convert( XML,@encoded).value('.','varbinary(max)'))
select @source as [Source], @encoded as [Encoded], @decoded as [Decoded]