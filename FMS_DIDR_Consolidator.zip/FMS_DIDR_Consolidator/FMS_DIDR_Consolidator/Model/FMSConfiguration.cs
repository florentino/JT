﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace FMS_DIDR_Consolidator.Model
{
    public class FMSConfiguration
    {
        private string _serverName;
        private string _portNo;
        private string _didrStageDIR;
        private string _userName;
        private string _sftpKey;
        private string _gpgKey;
        private string _ppkPathDIR;
        private string _fingerPrint;
        private string _timeToUpload;
        private string _timeToSend;
        private string _tsvGPGSource;
        private string _tsvBackupFolder;
        private string _logFolder;

        [Required(ErrorMessage = "Log Folder is required.")]
        public string LogFolder
        {
            get { return _logFolder; }
            set { _logFolder = value; }
        }

        [Required(ErrorMessage = "Backup Folder of TSV Files is required.")]
        public string TSVBackupFolder
        {
            get { return _tsvBackupFolder; }
            set { _tsvBackupFolder = value; }
        }

        [Required(ErrorMessage = "Source of TSV-GPG Files is required.")]
        public string TSV_GPG_Source
        {
            get { return _tsvGPGSource; }
            set { _tsvGPGSource = value; }
        }

        [Required(ErrorMessage = "Scheduled Time To Send is required.")]
        public string TimeToSend
        {
            get { return _timeToSend; }
            set { _timeToSend = value; }
        }

        [Required(ErrorMessage = "Scheduled Time To Upload is required.")]
        public string TimeToUpload
        {
            get { return _timeToUpload; }
            set { _timeToUpload = value; }
        }

        [Required(ErrorMessage = "Finger Print Code is required.")]
        public string FingerPrint
        {
            get { return _fingerPrint; }
            set { _fingerPrint = value; }
        }

        [Required(ErrorMessage = "PPK Path Directory is required.")]
        public string PPKPathDIR
        {
            get { return _ppkPathDIR; }
            set { _ppkPathDIR = value; }
        }

        [Required(ErrorMessage = "GPG Key is required.")]
        public string GPGKey
        {
            get { return _gpgKey; }
            set { _gpgKey = value; }
        }

        [Required(ErrorMessage = "SFTP Key is required.")]
        public string SFTPKey
        {
            get { return _sftpKey; }
            set { _sftpKey = value; }
        }

        [Required(ErrorMessage = "UserName is required.")]
        public string UserName
        {
            get { return _userName; }
            set { _userName = value; }
        }

        [Required(ErrorMessage = "DIDR Stage in Directory is required.")]
        public string DIDRStageDIR
        {
            get { return _didrStageDIR; }
            set { _didrStageDIR = value; }
        }

        [Required(ErrorMessage = "Port No is required.")]
        public string PortNo
        {
            get { return _portNo; }
            set { _portNo = value; }
        }

        [Required(ErrorMessage = "Server Name is required.")]
        public string ServerName
        {
            get { return _serverName; }
            set { _serverName = value; }
        }
    }
}
